## Biotime

Intragrate frappe (ERPNext) with BioTime (ZKTech).

#### License

MIT