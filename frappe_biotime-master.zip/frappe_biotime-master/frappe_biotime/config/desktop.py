# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from frappe import _

def get_data():
	return [
		{
			"module_name": "Biotime",
			"color": "green",
			"icon": "fa fa-device",
			"type": "module",
			"label": _("Biotime")
		}
	]
