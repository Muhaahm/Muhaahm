# -*- coding: utf-8 -*-
# Copyright (c) 2021, Mainul Islam and contributors
# For license information, please see license.txt

from __future__ import unicode_literals
import frappe
from frappe.model.document import Document
from frappe.utils.data import cint, now_datetime
import requests


DOCTYPE_FIELD_MAP = frappe._dict(
    {
        "Branch": frappe._dict({
            "remote_key_field": "remote_id",
            "fields": {
                "area_code": "branch_code",
                "area_name": "branch",
                "parent_area": "parent_branch",
            },
        }),
        "Department": frappe._dict({ #NOTE: Not Completed
            "remote_key_field": "remote_id",
            "fields": {
                "area_code": "branch_code",
                "area_name": "branch",
                "parent_area": "parent_branch",
            },
        }),
        "Employee": frappe._dict({
            "remote_key_field": "remote_id",
            "fields": {
                "emp_code": "employee_number",
                "nickname": "middle_name",
                "hire_date": "date_of_joining",
                "birthday": "date_of_birth",
                "email": "personal_email",
                "mobile": "cell_number"
            }
        }),
        "Employee Checkin": frappe._dict({
            "remote_key_field": "remote_id",
            "fields": {}
        })
    }
)


class BiotimeSettings(Document):
    def validate(self):
        self.fetch_jwt()

    def fetch_jwt(self):
        req = requests.post(
            f"{self.server_url}/jwt-api-token-auth/",
            {"username": self.username, "password": self.get_password()},
        )
        req.raise_for_status()
        if req.status_code == 200:
            self.set("jwt", req.json().get("token"))
        req.close()

    def send_req_to_biotime(self, method: str, url: str, payload=None):
        if not self.get("jwt"):
            self.fetch_jwt()
        headers = {"Content-Type": "application/json", "Authorization": f"JWT {self.jwt}"}
        params = None
        data = None
        if method.lower() == "get":
            params = payload
        else:
            data = payload
        res = requests.request(method=method, url=f"{self.server_url}{url}", params=params, data=data, headers=headers)
        res.raise_for_status()
        if res.status_code == 200:
            res.close()
            return frappe._dict(res.json())
        return frappe._dict()

    @frappe.whitelist()
    def fetch_area(self):
        res = self.send_req_to_biotime("GET", "/personnel/api/areas/")
        if res.get("count"):
            self.add_records_in_doctype("Branch", res.data)

    @frappe.whitelist()
    def fetch_employee(self):
        res = self.send_req_to_biotime("GET", "/personnel/api/employees/")
        if res.get("count"):
            self.add_records_in_doctype("Employee", res.data)

    def add_records_in_doctype(self, doctype, data):
        for row in data:
            map_dict = DOCTYPE_FIELD_MAP.get(doctype)
            if frappe.db.exists(doctype, {map_dict.remote_key_field: row["id"]}):
                continue
            doc = frappe.new_doc(doctype)
            for k, v in row.items():
                if isinstance(v, dict):
                    row[k] = v['id']
                elif isinstance(v, list):
                    row[k] = v[0]['id']
            doc.update(row)
            for k, v in map_dict.get("fields", {}).items():
                doc.set(v, row.get(k))
            doc.set(map_dict.remote_key_field, row["id"])
            doc.insert(ignore_permissions=True, ignore_mandatory=True)
            if cint(doc.meta.is_submittable):
                doc.submit()

    @frappe.whitelist()
    def fetch_transactions(self, start_time=None, end_time=None, page=0):
        args = {
            "start_time": start_time or self.start_time,
            "end_time": end_time or self.end_time,
            "page": page
        }
        req = self.send_req_to_biotime("GET", "/iclock/api/transactions/", args)
        if req.get("count"):
            for row in req.data:
                emp = frappe.db.get_value("Employee", {"employee_number": row["emp_code"]})
                if not emp:
                    continue
                doc = frappe.new_doc("Employee Checkin")
                doc.update({
                    "employee": emp,
                    "log_type": "OUT" if cint(row["punch_state"]) == 1 else "IN",
                    "time": row["punch_time"]
                })
                try:
                    doc.insert()
                except Exception as e:
                    print(e)
        frappe.db.commit()
        if req.get("next"):
            self.fetch_employee(start_time=start_time, end_time=end_time, page=req.get("next"))


def pull_transactions_hourly():
    doc = frappe.get_single("Biotime Settings")
    if not doc.jwt:
        return
        
    d = now_datetime()
    last_punch = frappe.db.sql("select time from `tabEmployee Checkin` order by time desc limit 1")
    if last_punch:
        last_punch = last_punch[0][0]

    if not last_punch:
        last_punch = doc.punch_pull_start_from

    if not last_punch:
        last_punch = "2020-01-01 00:00:00"

    doc.fetch_transactions(last_punch, d)
