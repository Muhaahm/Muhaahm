# -*- coding: utf-8 -*-
# Copyright (c) 2021, Mainul Islam and Contributors
# See license.txt
from __future__ import unicode_literals

# import frappe
import unittest

class TestBiotimeSettings(unittest.TestCase):
	pass
